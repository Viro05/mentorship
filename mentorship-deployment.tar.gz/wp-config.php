<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You will need to get this info from your web host ** //
/** The name of the database for WordPress */
define("DB_NAME", "mentorship_wp");

/** Database username */
define("DB_USER", "deorc");

/** Database password */
define("DB_PASSWORD", "shankara");

/** Database hostname */
define("DB_HOST", "localhost");

/** Database charset to use in creating database tables. */
define("DB_CHARSET", "utf8");

/** The database collate type. Don't change this if in doubt. */
define("DB_COLLATE", "");

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define(
    "AUTH_KEY",
    "9x]->QuqXNpNS|W+mt4*0ga,?jl1lgjElPr73~BY,MP%da?c]#p5G5MU/]WU)bkl",
);
define(
    "SECURE_AUTH_KEY",
    'qy-dFs^}R9+4%],CkfmTL_`sS;M#$+?Oo]Ru`:O?g-[~C68,@|V9dl_Bv>uMUMk3',
);
define(
    "LOGGED_IN_KEY",
    "=-I0vk_k[a>~E,D@@_bLNN@Jcq~`KWnLjra:A!]t]>vO*@GOc+o=ztH?|6GKR_g^",
);
define(
    "NONCE_KEY",
    "7z0-ak/X!d-TW)<IcWvG=(P+{pCVix]~w|n*R`>z>/!}!RX`A=>tw>=-|l,qU`0U",
);
define(
    "AUTH_SALT",
    ")14?~x%A.zL%Rh,uXJl?%)^jSc*-VOfk~Kr:_`F?Rpd!m=JoTw]||9mC}9?OgXtx",
);
define(
    "SECURE_AUTH_SALT",
    "2QE)gyv;%%dBOmg<9to|mg +]hX^:rl.:wg/,=oj;m0C!=|Zi#F[fku-*Tf4be+d",
);
define(
    "LOGGED_IN_SALT",
    "+6PtVrJzb*iUP.m Np4^ib^o11h]f(7D=N(w=3ZlYcmF}cn<EiIn@yW<Q4~nSZ+2",
);
define(
    "NONCE_SALT",
    '@:+|Ixs_?@e6P-r?;WLlHw.622}100+lYH|Ws$`Zwk0=h0r:j9_MZ= ;Cfr<!xE]',
);

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = "wp_";

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define("WP_DEBUG", true);
define("WP_DEBUG_LOG", true);
define("WP_DEBUG_DISPLAY", false);
define("SCRIPT_DEBUG", true);

/**
 * Development environment settings
 */
define("WP_ENVIRONMENT_TYPE", "development");

/**
 * Memory limit for development
 */
define("WP_MEMORY_LIMIT", "256M");

/**
 * File permissions
 */
define("FS_METHOD", "direct");

/* Add any custom values between this line and the "stop editing" line. */

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if (!defined("ABSPATH")) {
    define("ABSPATH", __DIR__ . "/");
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . "wp-settings.php";
